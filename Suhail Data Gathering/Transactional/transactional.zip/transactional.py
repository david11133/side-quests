#############################################################################################
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import csv
import sys
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Optional, Set, Tuple
import time
from collections import deque
import threading
#############################################################################################

###### Configurations ######

# API Endpoints
REGIONS_URL = "https://api2.suhail.ai/regions"
METRICS_URL = "https://api2.suhail.ai/api/mapMetrics/landMetrics/list"
TRANSACTIONS_URL = "https://api2.suhail.ai/transactions/neighbourhood"
TX_DETAILS_URL = "https://api2.suhail.ai/api/transactions/search"
PARCEL_URL = "https://api2.suhail.ai/api/parcel/search"
PRICE_METRICS_URL = "https://api2.suhail.ai/api/parcel/metrics/priceOfMeter"

# Settings
REGION_IDS = range(2, 17)
METRICS_LIMIT = 600
PAGE_SIZE = 1000
OUTPUT_FILE = "transactional_parcels.csv"
HISTORY_FILE = "transaction_price_history.csv"
TEST = False  # Set to True to test with small sample of data

# Performance settings
# OPTIMIZATION: Increased workers and split them by task type
MAX_NEIGHBORHOOD_WORKERS = 10  # Process 10 neighborhoods in parallel
MAX_DETAIL_WORKERS = 4         # Inside each neighborhood, use 4 threads for details
BATCH_SIZE = 25
METRICS_BATCH_SIZE = 20
REQUEST_TIMEOUT = 20           # Increased slightly for stability
CACHE_SIZE_LIMIT = 10000

#############################################################################################
# Locks for Thread Safety
csv_lock = threading.Lock()
history_csv_lock = threading.Lock()
seen_lock = threading.Lock()
print_lock = threading.Lock()

#############################################################################################
def create_session():
    """Create a requests session with retry logic and connection pooling"""
    session = requests.Session()
    
    adapter = HTTPAdapter(
        pool_connections=60,
        pool_maxsize=60,
        max_retries=Retry(
            total=4,
            backoff_factor=0.5,
            status_forcelist=[500, 502, 503, 504, 429],
            raise_on_status=False
        )
    )
    
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    return session

session = create_session()

#############################################################################################
# Caching
class LimitedCache:
    """Thread-safe LRU-like cache with size limit"""
    def __init__(self, max_size=1000):
        self.cache = {}
        self.access_order = deque()
        self.max_size = max_size
        self.lock = threading.Lock() # OPTIMIZATION: Added lock
    
    def get(self, key, default=None):
        with self.lock:
            return self.cache.get(key, default)
    
    def set(self, key, value):
        with self.lock:
            if key not in self.cache and len(self.cache) >= self.max_size:
                if self.access_order:
                    old_key = self.access_order.popleft()
                    self.cache.pop(old_key, None)
            self.cache[key] = value
            if key in self.access_order:
                self.access_order.remove(key)
            self.access_order.append(key)
    
    def __contains__(self, key):
        with self.lock:
            return key in self.cache

transaction_details_cache = LimitedCache(max_size=CACHE_SIZE_LIMIT)
parcel_geometry_cache = LimitedCache(max_size=CACHE_SIZE_LIMIT)
seen_transactions: Set[Tuple] = set()

#############################################################################################
# Loggings
def log_progress(msg):
    """Print clean progress message overwriting current line"""
    with print_lock:
        sys.stdout.write(f"\r{msg.ljust(100)}")
        sys.stdout.flush()

def log_info(msg):
    """Print permanent info message"""
    with print_lock:
        sys.stdout.write(f"\n{msg}")
        sys.stdout.flush()

#############################################################################################
def is_valid_subdivision(subdivision_no):
    return subdivision_no and str(subdivision_no).strip().isdigit()

#############################################################################################
def needs_details_fetch(tx):
    has_type = tx.get("type") is not None
    has_metrics_type = tx.get("metricsType") is not None
    has_total_area = tx.get("totalArea") is not None
    if has_type and has_metrics_type and has_total_area:
        return False
    return True

#############################################################################################
def extract_coordinates(tx, details):
    centroid_x = tx.get("centroidX")
    centroid_y = tx.get("centroidY")
    if centroid_x: return centroid_x, centroid_y
    
    centroid_x = details.get("centroidX")
    centroid_y = details.get("centroidY")
    if centroid_x: return centroid_x, centroid_y
    
    if details.get("centroid"):
        return details["centroid"].get("x"), details["centroid"].get("y")
    
    if details.get("parcels") and len(details["parcels"]) > 0:
        p = details["parcels"][0]
        return p.get("centroidX"), p.get("centroidY")
    
    return None, None

#############################################################################################
def needs_geometry_fetch(tx, details, centroid_x):
    if centroid_x: return False
    if details.get("geometry") or details.get("polygonData"): return False
    if not (tx.get("parcelNo") and tx.get("subdivisionNo")): return False
    return True

#############################################################################################
def fetch_transaction_details(region_id: int, tx_number: str) -> dict:
    try:
        resp = session.get(
            TX_DETAILS_URL,
            params={"transactionNo": tx_number, "regionId": region_id},
            timeout=REQUEST_TIMEOUT
        )
        resp.raise_for_status()
        data = resp.json().get("data", [])
        return data[0] if data else {}
    except Exception:
        return {}

#############################################################################################
def fetch_parcel_geometry(region_id: int, province_id: int, subdivision_no: str, parcel_no: str) -> Optional[dict]:
    if not is_valid_subdivision(subdivision_no):
        return None
    try:
        resp = session.get(
            PARCEL_URL,
            params={
                "regionId": region_id,
                "provinceId": province_id,
                "subdivisionNo": subdivision_no,
                "parcelNo": parcel_no,
                "offset": 0,
                "limit": 10
            },
            timeout=REQUEST_TIMEOUT
        )
        if resp.status_code in (404, 410): return None
        resp.raise_for_status()
        details = resp.json().get("data", {}).get("parcelDetails", [])
        return details[0].get("geometry") if details else None
    except Exception:
        return None

#############################################################################################
def fetch_price_metrics_batch(parcel_ids: List[int]) -> List[dict]:
    """Fetch price metrics for a batch of parcel IDs"""
    if not parcel_ids:
        return []
    
    ids_str = ",".join(map(str, parcel_ids))
    
    try:
        resp = session.get(
            PRICE_METRICS_URL,
            params={
                "parcelObjsIds": ids_str,
                "groupingType": "Monthly"
            },
            timeout=REQUEST_TIMEOUT
        )
        resp.raise_for_status()
        return resp.json().get("data", [])
    except Exception as e:
        return []

#############################################################################################
def batch_fetch_details(region_id: int, tx_list: List[dict]) -> Dict[str, dict]:
    results = {}
    to_fetch = []
    
    for tx in tx_list:
        tx_number = tx.get("transactionNumber")
        if tx_number in transaction_details_cache:
            results[tx_number] = transaction_details_cache.get(tx_number)
        else:
            to_fetch.append(tx_number)
    
    if not to_fetch:
        return results
    
    # OPTIMIZATION: Reduced internal max workers to prevent thread explosion (since this runs inside another thread)
    with ThreadPoolExecutor(max_workers=MAX_DETAIL_WORKERS) as executor:
        future_to_tx = {
            executor.submit(fetch_transaction_details, region_id, tx_num): tx_num 
            for tx_num in to_fetch
        }
        for future in as_completed(future_to_tx):
            tx_number = future_to_tx[future]
            try:
                details = future.result()
                transaction_details_cache.set(tx_number, details)
                results[tx_number] = details
            except Exception:
                transaction_details_cache.set(tx_number, {})
                results[tx_number] = {}
    return results

#############################################################################################
def batch_fetch_geometries(requests_list: List[Tuple]) -> Dict[Tuple, Optional[dict]]:
    results = {}
    to_fetch = []
    
    for req in requests_list:
        if req in parcel_geometry_cache:
            results[req] = parcel_geometry_cache.get(req)
        else:
            to_fetch.append(req)
    
    if not to_fetch:
        return results
    
    with ThreadPoolExecutor(max_workers=MAX_DETAIL_WORKERS) as executor:
        future_to_req = {
            executor.submit(fetch_parcel_geometry, *req): req 
            for req in to_fetch
        }
        for future in as_completed(future_to_req):
            req = future_to_req[future]
            try:
                results[req] = future.result()
                parcel_geometry_cache.set(req, results[req])
            except Exception:
                results[req] = None
                parcel_geometry_cache.set(req, None)
    return results

#############################################################################################
def batch_process_metrics(transactions: List[dict]):
    """Process price metrics for a list of transactions"""
    id_map = {} 
    ids_to_fetch = []
    
    for tx in transactions:
        t_id = tx.get("parcelObjectId")
        t_num = tx.get("transactionNumber")
        if t_id:
            ids_to_fetch.append(t_id)
            id_map[t_id] = t_num

    if not ids_to_fetch:
        return

    all_metrics_rows = []
    
    # fetch batches in parallel
    batches = [ids_to_fetch[i:i + METRICS_BATCH_SIZE] for i in range(0, len(ids_to_fetch), METRICS_BATCH_SIZE)]
    
    with ThreadPoolExecutor(max_workers=MAX_DETAIL_WORKERS) as executor:
        futures = [executor.submit(fetch_price_metrics_batch, batch) for batch in batches]
        
        for future in as_completed(futures):
            metrics_data = future.result()
            
            for item in metrics_data:
                parcel_obj_id = item.get("parcelObjId")
                neighborhood_id = item.get("neighborhoodId")
                
                # 1. Parcel Metrics
                for pm in item.get("parcelMetrics", []):
                    all_metrics_rows.append({
                        "parcelObjId": parcel_obj_id,
                        "transactionNumber": id_map.get(parcel_obj_id, ""),
                        "neighborhoodId": neighborhood_id,
                        "type": "Parcel Specific",
                        "month": pm.get("month"),
                        "year": pm.get("year"),
                        "metricsType": pm.get("metricsType"),
                        "averagePriceOfMeter": pm.get("avaragePriceOfMeter")
                    })
                    
                # 2. Neighborhood Metrics
                for nm in item.get("neighborhoodMetrics", []):
                    all_metrics_rows.append({
                        "parcelObjId": parcel_obj_id,
                        "transactionNumber": id_map.get(parcel_obj_id, ""),
                        "neighborhoodId": nm.get("neighborhoodId"),
                        "type": "Neighborhood Average",
                        "month": nm.get("month"),
                        "year": nm.get("year"),
                        "metricsType": nm.get("metricsType"),
                        "averagePriceOfMeter": nm.get("avaragePriceOfMeter")
                    })

    append_history_to_csv(all_metrics_rows)

#############################################################################################
def append_to_csv(new_rows):
    if not new_rows: return
    # OPTIMIZATION: Thread-safe writing
    with csv_lock:
        try:
            with open(OUTPUT_FILE, 'r', encoding="utf-8-sig"): file_exists = True
        except FileNotFoundError: file_exists = False
        
        with open(OUTPUT_FILE, "a", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=new_rows[0].keys())
            if not file_exists: writer.writeheader()
            writer.writerows(new_rows)

#############################################################################################
def append_history_to_csv(new_rows):
    """Append price history metrics to separate CSV"""
    if not new_rows: return
    
    # OPTIMIZATION: Thread-safe writing
    with history_csv_lock:
        try:
            with open(HISTORY_FILE, 'r', encoding="utf-8-sig"): file_exists = True
        except FileNotFoundError: file_exists = False
        
        fieldnames = ["parcelObjId", "transactionNumber", "neighborhoodId", "type", "month", "year", "metricsType", "averagePriceOfMeter"]
        
        with open(HISTORY_FILE, "a", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            if not file_exists: writer.writeheader()
            writer.writerows(new_rows)

#############################################################################################
def build_row(region_id, province_id, province_name, neighborhood_id, neighborhood_name, tx, details, geometry=None, region_dict=None, province_dict=None):
    tx_number = tx.get("transactionNumber")
    centroid_x, centroid_y = extract_coordinates(tx, details)
    
    region_data = region_dict.get(region_id, {})
    boundary = region_data.get("restrictBoundaryBox", {})
    
    row = {
        "regionId": region_id,
        "region_name": region_data.get("name", ""),
        "region_centroid_x": region_data.get("centroid", {}).get("x", ""),
        "region_centroid_y": region_data.get("centroid", {}).get("y", ""),
        "boundary_sw_x": boundary.get("southwest", {}).get("x", ""),
        "boundary_sw_y": boundary.get("southwest", {}).get("y", ""),
        "boundary_ne_x": boundary.get("northeast", {}).get("x", ""),
        "boundary_ne_y": boundary.get("northeast", {}).get("y", ""),
        "region_image": region_data.get("image", ""),
        "province_id": province_id or "",
        "provinceName": province_name or "",
        "province_centroid_x": province_dict.get(province_id, {}).get("centroid", {}).get("x", ""),
        "province_centroid_y": province_dict.get(province_id, {}).get("centroid", {}).get("y", ""),
        "neighborhoodId": neighborhood_id,
        "neighborhoodName": neighborhood_name,
        "رقم الصفقة": tx_number or "",
        "رقم المخطط": tx.get("subdivisionNo") or "",
        "رقم البلوك": tx.get("blockNo") or "---",
        "رقم القطعة": tx.get("parcelNo") or "",
        "قيمة الصفقة (ï·¼)": tx.get("transactionPrice") or "",
        "سعر المتر (ï·¼)": tx.get("priceOfMeter") or "",
        "تاريخ الصفقة": tx.get("transactionDate") or "",
        "نوع الأرض": details.get("type") if details else "",
        "نوع الاستخدام": details.get("metricsType") if details else "",
        "المساحة الإجمالية": details.get("totalArea") if details else "",
        "المصدر": details.get("transactionSource") if details else "",
        "sellingType": details.get("sellingType") if details else "",
        "landUseGroup": details.get("landUseGroup") if details else "",
        "propertyType": details.get("propertyType") if details else "",
        "centroidX": centroid_x or "",
        "centroidY": centroid_y or "",
        "parcelObjId": tx.get("parcelObjectId", ""), 
        "polygonData": json.dumps(details.get("polygonData"), ensure_ascii=False) if details and details.get("polygonData") else "",
        "geometry": json.dumps((details.get("geometry") if details else None) or geometry, ensure_ascii=False) if (details and details.get("geometry")) or geometry else ""
    }
    return row

#############################################################################################
def fetch_regions():
    response = session.get(REGIONS_URL)
    response.raise_for_status()
    regions = response.json()["data"]
    r_dict, p_dict = {}, {}
    for r in regions:
        r_dict[r["id"]] = r
        for p in r.get("provinces", []):
            p_dict[p["id"]] = p
    return r_dict, p_dict

#############################################################################################
def process_neighborhood(item, region_id, region_dict, province_dict):
    """Refactored to run as a single worker task"""
    neighborhood_id = item["neighborhoodId"]
    neighborhood_name = item["neighborhoodName"]
    # log_progress(f"   Starting Neighborhood: {neighborhood_name} ({neighborhood_id})")

    # Fetch Transactions
    all_transactions = []
    page = 0
    while True:
        try:
            tx_resp = session.get(
                TRANSACTIONS_URL,
                params={"regionId": region_id, "neighbourhoodId": neighborhood_id, "page": page, "pageSize": PAGE_SIZE},
                timeout=30
            )
            tx_resp.raise_for_status()
            txs = tx_resp.json().get("data", [])
            if not txs: break
            all_transactions.extend(txs)
            page += 1
            if TEST and page >= 1: break
        except Exception:
            break
    
    if not all_transactions: 
        return 0

    # Filter Duplicates (Thread Safe)
    new_transactions = []
    with seen_lock:
        for tx in all_transactions:
            key = (region_id, neighborhood_id, tx.get("transactionNumber"))
            if key not in seen_transactions:
                seen_transactions.add(key)
                new_transactions.append(tx)
    
    if not new_transactions: 
        return 0

    # 1. Fetch Details
    tx_needing_details = [tx for tx in new_transactions if needs_details_fetch(tx)]
    details_map = batch_fetch_details(region_id, tx_needing_details) if tx_needing_details else {}
    
    # 2. Prepare Details Map for all
    for tx in new_transactions:
        if tx.get("transactionNumber") not in details_map:
            details_map[tx.get("transactionNumber")] = {
                "type": tx.get("type"), "metricsType": tx.get("metricsType"),
                "totalArea": tx.get("totalArea"), "transactionSource": tx.get("transactionSource"),
                "sellingType": tx.get("sellingType"), "landUseGroup": tx.get("landUseGroup"),
                "propertyType": tx.get("propertyType"), "centroidX": tx.get("centroidX"),
                "centroidY": tx.get("centroidY"), "geometry": tx.get("geometry"),
                "polygonData": tx.get("polygonData"), "provinceId": tx.get("provinceId")
            }

    # 3. Fetch Geometries
    geo_reqs = []
    for tx in new_transactions:
        details = details_map.get(tx.get("transactionNumber"), {})
        cx, _ = extract_coordinates(tx, details)
        if needs_geometry_fetch(tx, details, cx):
            prov_id = details.get("provinceId") or item.get("provinceId")
            if tx.get("parcelNo") and tx.get("subdivisionNo") and prov_id:
                geo_reqs.append(((region_id, prov_id, tx.get("subdivisionNo"), tx.get("parcelNo")), tx.get("transactionNumber")))
    
    geo_map = {}
    if geo_reqs:
        unique_reqs = list(set([r for r, _ in geo_reqs]))
        geo_results = batch_fetch_geometries(unique_reqs)
        for req, tnum in geo_reqs:
            geo_map[tnum] = geo_results.get(req)

    # 4. Fetch Price History Metrics
    batch_process_metrics(new_transactions)

    # 5. Save Rows
    rows_to_save = []
    for tx in new_transactions:
        tnum = tx.get("transactionNumber")
        details = details_map.get(tnum, {})
        geom = geo_map.get(tnum)
        prov_id = details.get("provinceId") or item.get("provinceId")
        
        rows_to_save.append(build_row(
            region_id, prov_id, item.get("provinceName"), neighborhood_id, 
            neighborhood_name, tx, details, geom, region_dict, province_dict
        ))
    
    append_to_csv(rows_to_save)
    
    # Log completion for this neighborhood
    log_progress(f"   Processed {neighborhood_name}: {len(rows_to_save)} items")
    return len(rows_to_save)

#############################################################################################
def process_region(region_id, region_dict, province_dict):
    log_info(f">> Starting Region {region_id}: {region_dict.get(region_id, {}).get('name', 'Unknown')}")
    region_rows = 0
    offset = 0
    
    while True:
        # Fetch Neighborhoods (Metrics)
        try:
            metrics_resp = session.get(METRICS_URL, params={"regionId": region_id, "offset": offset, "limit": METRICS_LIMIT}, timeout=30)
            metrics_resp.raise_for_status()
        except Exception as e:
            log_info(f"Error fetching metrics list: {e}")
            break

        items = metrics_resp.json().get("data", {}).get("items", [])
        if not items: break

        if TEST: items = items[:3]

        log_info(f"   Fetched {len(items)} neighborhoods")

        # parallel Neighborhood Processing
        with ThreadPoolExecutor(max_workers=MAX_NEIGHBORHOOD_WORKERS) as executor:
            # Submit all neighborhood tasks
            futures = [
                executor.submit(process_neighborhood, item, region_id, region_dict, province_dict)
                for item in items
            ]
            
            # Gather results
            for future in as_completed(futures):
                try:
                    region_rows += future.result()
                except Exception as e:
                    # Log error but continue
                    pass

        offset += METRICS_LIMIT
        if TEST: break
    
    log_info(f"✓ Region {region_id} Completed. Total rows: {region_rows}")
    return region_rows

#############################################################################################
if __name__ == "__main__":
    print(f"{'='*60}")
    print(f"SUHAIL.AI SCRAPER - OPTIMIZED")
    print(f"Main Data: {OUTPUT_FILE}")
    print(f"Price History: {HISTORY_FILE}")
    print(f"{'='*60}")
    
    start_t = time.time()
    total_r = 0
    
    try:
        log_info("Fetching metadata (Regions/Provinces)...")
        r_dict, p_dict = fetch_regions()
        
        for rid in REGION_IDS:
            total_r += process_region(rid, r_dict, p_dict)
            
    except KeyboardInterrupt:
        log_info(" ----- Scraper interrupted by user -----")
    except Exception as e:
        log_info(f"------ Critical Error: {e} ------")
    
    elapsed = time.time() - start_t
    print(f"\n{'='*60}")
    print(f"DONE. Processed {total_r} transactions in {elapsed/60:.1f} min.")